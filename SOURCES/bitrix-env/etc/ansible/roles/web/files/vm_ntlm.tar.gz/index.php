<?
define("NEED_AUTH", true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");

?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>