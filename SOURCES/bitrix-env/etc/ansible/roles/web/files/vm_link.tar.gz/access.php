<?
$PERM["personal"]["7"]="W";
$PERM["catalog"]["7"]="W";
$PERM["news"]["7"]="W";
$PERM["about"]["7"]="W";
$PERM["index.php"]["7"]="W";
$PERM["/"]["*"]="R";
?>